import { Component, OnInit } from '@angular/core';
import { Jugador } from '../Jugador';
import { Pieza } from '../pieza'
import { Celda } from '../Celda'
import { from } from 'rxjs';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-tablero',
  templateUrl: './tablero.component.html',
  styleUrls: ['./tablero.component.css']
})
export class TableroComponent implements OnInit {

  nom1 = this.route.snapshot.paramMap.get('id1')
  nom2 = this.route.snapshot.paramMap.get('id2')

  ngOnInit() {
    
  }
  //FICHAS BLANCAS
  PeonBlanco: Pieza = {
    texto: "&#9817",
  };
  TorreBlanco: Pieza = {
    texto: "&#9814;",
  };
  AlfilBlanco: Pieza = {
    texto: "&#9815;",
  };
  CaballoBlanco: Pieza = {
    texto: "&#9816;",
  };
  ReyBlanco: Pieza = {
    texto: "&#9813;",
  };
  ReinaBlanco: Pieza = {
    texto: "&#9812",
  }
  //FICHAS NEGRAS
  PeonNegro: Pieza = {
    texto: "&#9823;",
  };
  TorreNegro: Pieza = {
    texto: "&#9820;",
  };
  AlfilNegro: Pieza = {
    texto: "&#9821;",
  };
  CaballoNegro: Pieza = {
    texto: "&#9822;",
  };
  ReyNegro: Pieza = {
    texto: "&#9818;",
  };
  ReinaNegro: Pieza = {
    texto: "&#9819;",
  }
  Vacio: Pieza = {
    texto: "",
  }
  jugador1: Jugador = {
    id: 1,
    nombre: this.nom1
  };
  jugador2: Jugador = {
    id: 2,
    nombre: this.nom2
  };


  filas = [];

  constructor(private router: Router, private route: ActivatedRoute) {
    this.CrearTablero();
  }

  CrearTablero() {
    for (var i = 0; i < 8; i++) {
      this.filas[i] = [];
      for (var j = 0; j < 8; j++) {
        var celda: Celda = {
          clase: "",
          id: ""
        };
        celda.id = i + "" + j;
        if ((i + j) % 2 == 0) {
          celda.clase = 'P1';
        } else {
          celda.clase = 'P2';
        }
        this.filas[i][j] = celda;
      }
    }
  }

  inicializarTablero() {
    for (var i = 0; i < 8; i++) {
      for (var j = 0; j < 8; j++) {
        if (i == 0) {
          if (j == 0 || j == 7) {
            document.getElementById(i + "" + j).innerHTML = this.TorreNegro.texto;
          } else if (j == 1 || j == 6) {
            document.getElementById(i + "" + j).innerHTML = this.CaballoNegro.texto;
          } else if (j == 2 || j == 5) {
            document.getElementById(i + "" + j).innerHTML = this.AlfilNegro.texto;
          } else if (j == 3) {
            document.getElementById(i + "" + j).innerHTML = this.ReinaNegro.texto;
          } else if (j == 4) {
            document.getElementById(i + "" + j).innerHTML = this.ReyNegro.texto;
          }
        } else if (i == 1) {
          document.getElementById(i + "" + j).innerHTML = this.PeonNegro.texto;
        } else if (i == 6) {
          document.getElementById(i + "" + j).innerHTML = this.PeonBlanco.texto;
        } else if (i == 7) {
          if (j == 0 || j == 7) {
            document.getElementById(i + "" + j).innerHTML = this.TorreBlanco.texto;
          } else if (j == 1 || j == 6) {
            document.getElementById(i + "" + j).innerHTML = this.CaballoBlanco.texto;
          } else if (j == 2 || j == 5) {
            document.getElementById(i + "" + j).innerHTML = this.AlfilBlanco.texto;
          } else if (j == 3) {
            document.getElementById(i + "" + j).innerHTML = this.ReyBlanco.texto;
          } else if (j == 4) {
            document.getElementById(i + "" + j).innerHTML = this.ReinaBlanco.texto;
          }
        } else {
          document.getElementById(i + "" + j).innerHTML = this.Vacio.texto;
        }
      }
    }
  }

  RecibirJugada(Jugada: string) {
    this.PintarNuevaCasilla(Jugada.substr(0, 2), Jugada.substr(3, 4));
    this.BorrarCasilla(Jugada.substr(0, 2));
  }
  PintarNuevaCasilla(PosIn: string, PosFin) {
    var aux = document.getElementById(PosIn).innerHTML;
    document.getElementById(PosFin).innerHTML = aux;
    console.log(aux);

  }
  BorrarCasilla(Pos: string) {
    document.getElementById(Pos).innerHTML = "";
  }
}