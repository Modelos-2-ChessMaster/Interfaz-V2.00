export interface Pieza{
    texto:string;
}