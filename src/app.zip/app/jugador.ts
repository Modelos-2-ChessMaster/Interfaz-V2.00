export interface Jugador{
    id:number;
    nombre:string;
}