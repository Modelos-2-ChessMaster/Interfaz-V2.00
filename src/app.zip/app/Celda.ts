export interface Celda{
    clase: string;
    id: string;
}